package artificial.intelligence.project;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;
import weka.core.Instance;
import weka.classifiers.evaluation.Prediction;
import weka.core.FastVector;
import java.io.BufferedReader;
import java.io.FileReader;
import weka.classifiers.evaluation.NominalPrediction;


public class ArtificialIntelligenceProject {
 
    public static void main(String[] args) throws Exception{
    	
         
         //System.out.println(np.predicted());
        firstpage f = new firstpage();
        f.setVisible(true);
        
    }
}
