/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package artificial.intelligence.project;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.evaluation.NominalPrediction;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;

/**
 *
 * @author Lilani
 */
public class predict1 {
    
    public static float age;
    public static float gpa;
    public static String program;
    public static String gender;
    
    String result;
    
    predict1(float a, float g, String p, String gen) {
      //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      age = a;
      gpa = g;
      program = p;
      gender = gen;
     
    }
    
    public void weka() throws FileNotFoundException, IOException, Exception{
        BufferedReader datafile = new BufferedReader(new FileReader("profile.txt"));
    	 
		Instances data = new Instances(datafile);
		data.setClassIndex(data.numAttributes() - 1); 
    	
		Classifier model= new MultilayerPerceptron(); 
		
		Evaluation evaluation = new Evaluation(data);
		 
		model.buildClassifier(data);
                // Declare the feature vector
        FastVector fvWekaAttributes = new FastVector(5);
        fvWekaAttributes.addElement(data.attribute(0));    
        fvWekaAttributes.addElement(data.attribute(1));    
        fvWekaAttributes.addElement(data.attribute(2));   
        fvWekaAttributes.addElement(data.attribute(3));
        fvWekaAttributes.addElement(data.attribute(4));
    	        // Create the instance
         Instance iExample = new Instance(5);
         iExample.setValue((Attribute)fvWekaAttributes.elementAt(0), age );      
         iExample.setValue((Attribute)fvWekaAttributes.elementAt(1), gpa);      
         iExample.setValue((Attribute)fvWekaAttributes.elementAt(2), program);
         iExample.setValue((Attribute)fvWekaAttributes.elementAt(3), gender);
        // iExample.setValue((Attribute)fvWekaAttributes.elementAt(4), "Y"); 
          
         
         Instances isTestSet = new Instances("Rel", fvWekaAttributes, 10);
         
         isTestSet.setClassIndex(4);
       
         
         // add the instance
         isTestSet.add(iExample);
         
         evaluation.evaluateModel(model, isTestSet);
 
         FastVector predictions=new FastVector();
         
         predictions.appendElements(evaluation.predictions());
         
         //System.out.println(pridictions.size());
         
         
         NominalPrediction np = (NominalPrediction) predictions.elementAt(0);
         
         String result;
         
         if(np.predicted()==0){
        	 System.out.println("ENGAGED:  NO");
                 result = "NO";
        	 
         }else{
        	 System.out.println("ENGAGED: YES");
        	 result = "YES";
         }
         
         predictshow sh  = new predictshow(result,age,gpa,program,gender);
         predictshow shh = new predictshow();
         shh.setVisible(true);
    }
}
